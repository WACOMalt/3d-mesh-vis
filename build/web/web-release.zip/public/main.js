// 3D Mesh Visualizer - ES Modules Version
// Uses importmap for Three.js imports

import * as THREE from 'three';
import { OrbitControls } from 'three/controls';
import { OBJLoader } from 'three/loaders';

// ===== Loading Overlay Helpers =====
const loadingOverlay = document.getElementById('loading-overlay');
const loadingText = loadingOverlay?.querySelector('.loading-text');

function showLoading(message = 'Loading model...') {
    if (loadingOverlay) {
        if (loadingText) loadingText.textContent = message;
        loadingOverlay.classList.add('visible');
    }
}

function hideLoading() {
    if (loadingOverlay) {
        loadingOverlay.classList.remove('visible');
    }
}

// ===== Scene Setup =====
const scene = new THREE.Scene();

// ===== Sky Shader Setup =====
// Procedural sky shader
const createSkyMesh = () => {
    const vertexShader = `
    varying vec3 vWorldPosition;
    void main() {
      vec4 worldPosition = modelMatrix * vec4(position, 1.0);
      vWorldPosition = worldPosition.xyz;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `;

    const fragmentShader = `
    precision highp float;
    varying vec3 vWorldPosition;
    uniform vec3 sunPosition;
    uniform float showHorizonCutoff;
    uniform vec3 horizonColor;
    
    void main() {
      vec3 direction = normalize(vWorldPosition - cameraPosition);
      vec3 up = vec3(0.0, 1.0, 0.0);
      
      // Hard cut at horizon - anything below uses horizonColor (only when enabled)
      if (direction.y < 0.0 && showHorizonCutoff > 0.5) {
        gl_FragColor = vec4(horizonColor, 1.0);
        return;
      }
      
      // Simple sky based on sun position
      float sunDot = dot(direction, normalize(sunPosition));
      float upDot = dot(direction, up);
      
      // Sky color: blue at top, warmer at horizon
      vec3 skyColor = mix(
        vec3(0.5, 0.7, 1.0),  // blue
                vec3(0.2, 0.2, 0.2),  // dark grey
        smoothstep(0.0, -0.3, upDot)
      );
      
      // Sun glow
      vec3 sunColor = vec3(1.0, 0.9, 0.7);
      float sunIntensity = exp(-pow(1.0 - sunDot, 2.0) * 20.0);
      skyColor += sunColor * sunIntensity * 0.5;
      
      gl_FragColor = vec4(skyColor, 1.0);
    }
  `;

    const geometry = new THREE.SphereGeometry(1, 32, 32);
    const material = new THREE.ShaderMaterial({
        name: 'SkyShader',
        side: THREE.BackSide,
        depthWrite: false,
        uniforms: {
            sunPosition: { value: new THREE.Vector3(1, 1, 1).normalize() },
            showHorizonCutoff: { value: 0.0 },
            horizonColor: { value: new THREE.Color(0x333333) }
        },
        vertexShader: vertexShader,
        fragmentShader: fragmentShader
    });

    return new THREE.Mesh(geometry, material);
};

const sky = createSkyMesh();
sky.scale.set(100, 100, 100);

// Sun position for sky shader
let sunElevation = 45;
let sunAzimuth = 135;
const sunVector = new THREE.Vector3();

function updateSunPosition() {
    const phi = THREE.MathUtils.degToRad(90 - sunElevation);
    const theta = THREE.MathUtils.degToRad(sunAzimuth);
    sunVector.setFromSphericalCoords(1, phi, theta);
    sky.material.uniforms.sunPosition.value.copy(sunVector);

    // Also update keyLight position to match sun (scaled to reasonable distance)
    const sunDistance = 10;
    keyLight.position.copy(sunVector).multiplyScalar(sunDistance);
}

// Sky follows camera
scene.add(sky);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.z = 3;

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
renderer.setClearColor(0x333333);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.physicallyCorrectLights = true;
document.getElementById('canvas-container').appendChild(renderer.domElement);

// ===== Lighting Setup =====
// Hemisphere light to match sky colors (blue top, warm bottom)
const hemisphereLight = new THREE.HemisphereLight(
    0x87ceeb, // sky color (blue)
    0xffa644, // ground color (warm orange)
    0.6       // intensity
);
scene.add(hemisphereLight);

// Directional lights grouped to rotate together
const lightsGroup = new THREE.Group();
scene.add(lightsGroup);

// Key light (main) - tracks the sun position
const keyLight = new THREE.DirectionalLight(0xffffff, 6.0);
keyLight.position.set(4, 5, 3);
keyLight.castShadow = false;
scene.add(keyLight);

// Initialize sun position to match sky and keyLight
updateSunPosition();

// Rim light - back left
const rimLight = new THREE.DirectionalLight(0xffffff, 1.5);
rimLight.position.set(-4, 5, -3);
rimLight.castShadow = false;
lightsGroup.add(rimLight);

// ===== Helpers =====
// Grid helper
const gridHelper = new THREE.GridHelper(10, 10);
gridHelper.position.y = -1;
scene.add(gridHelper);

// Axes helper (navigation)
const axesHelper = new THREE.AxesHelper(1);
camera.add(axesHelper);
scene.add(camera);
axesHelper.position.set(1, 0.50, -1);
axesHelper.scale.set(0.1, 0.1, 0.1);

// Floor axes helper with custom colors
const floorAxesGeometry = new THREE.BufferGeometry();
const floorAxesPositions = new Float32Array([
    0, 0, 0, 6, 0, 0,  // X axis (red)
    0, 0, 0, 0, 0, 0,  // Y axis (black)
    0, 0, 0, 0, 0, 6   // Z axis (blue)
]);
const floorAxesColors = new Float32Array([
    1, 0, 0, 1, 0, 0,  // Red for X
    0, 0, 0, 0, 0, 0,  // Black for Y
    0, 0, 1, 0, 0, 1   // Blue for Z
]);
floorAxesGeometry.setAttribute('position', new THREE.BufferAttribute(floorAxesPositions, 3));
floorAxesGeometry.setAttribute('color', new THREE.BufferAttribute(floorAxesColors, 3));
const floorAxesMaterial = new THREE.LineBasicMaterial({ vertexColors: true, linewidth: 2 });
const floorAxesHelper = new THREE.LineSegments(floorAxesGeometry, floorAxesMaterial);
floorAxesHelper.scale.set(1, -1, 1);
floorAxesHelper.position.y = -0.999;
scene.add(floorAxesHelper);

// ===== Controls =====
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;

// ===== Data Storage =====
let currentShape = 'cube';
let currentGeometry = null;
let currentMaterial = null;  // Store original material for textures
let verticesData = [];
let edgesData = [];
let facesData = [];
let vertices = null;  // InstancedMesh
let vertexScales = [];  // Track individual vertex scales for animation
let edgesMesh = null;  // Merged edges mesh
let edgeVisibility = [];  // Track individual edge visibility for animation
let facesMesh = null;  // Merged faces mesh
let facesInnerMesh = null; // Back-side faces for inside color
let faceVisibility = [];  // Track individual face visibility for animation
let mesh = null;
// Animation State Tracking
let activeVerticesTween = null;
let activeEdgesTween = null;
let activeFacesTween = null;
let activeMeshTween = null;

// ===== Custom Shader Material for Edges =====
const edgeShaderMaterial = new THREE.ShaderMaterial({
    uniforms: {},
    vertexShader: `
        attribute float visibility;
        varying float vVisibility;
        
        void main() {
            vVisibility = visibility;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
    `,
    fragmentShader: `
        varying float vVisibility;
        
        void main() {
            gl_FragColor = vec4(0.0, 1.0, 0.0, vVisibility);
        }
    `,
    transparent: true,
    linewidth: 3
});

// ===== Custom Shader Material for Faces =====
const faceShaderMaterial = new THREE.ShaderMaterial({
    uniforms: {
        keyLightPos: { value: new THREE.Vector3(4, 5, 3) },
        rimLightPos: { value: new THREE.Vector3(-4, 5, -3) },
        outsideColor: { value: new THREE.Color(0x0044ff) },
        insideColor: { value: new THREE.Color(0xff6600) },
        inside: { value: 0.0 }
    },
    vertexShader: `
        attribute float visibility;
        varying float vVisibility;
        varying vec3 vNormal;
        varying vec3 vWorldPosition;
        
        void main() {
            vVisibility = visibility;
            // Transform normal to world space
            vNormal = normalize(mat3(modelMatrix) * normal);
            vWorldPosition = (modelMatrix * vec4(position, 1.0)).xyz;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
    `,
    fragmentShader: `
        uniform vec3 keyLightPos;
        uniform vec3 rimLightPos;
        uniform vec3 outsideColor;
        uniform vec3 insideColor;
        uniform float inside;
        
        varying float vVisibility;
        varying vec3 vNormal;
        varying vec3 vWorldPosition;

        // Hash for dithered (opaque) visibility reveal
        float hash(vec3 p) {
            return fract(sin(dot(p, vec3(12.9898, 78.233, 45.164))) * 43758.5453);
        }
        
        void main() {
            // Opaque reveal: discard pixels based on animated visibility
            float dither = hash(vWorldPosition * 10.0);
            if (dither >= vVisibility) discard;

            // Different colors for outside vs inside
            vec3 baseColor = mix(outsideColor, insideColor, inside);
            vec3 N = normalize(mix(vNormal, -vNormal, inside));
            vec3 V = normalize(cameraPosition - vWorldPosition);
            
            // Normalized light directions
            vec3 keyLight = normalize(keyLightPos - vWorldPosition);
            vec3 rimLight = normalize(rimLightPos - vWorldPosition);
            
            // Lambert diffuse
            float keyDiff = max(dot(N, keyLight), 0.0) * 2.0;
            float rimDiff = max(dot(N, rimLight), 0.0) * 1.5;
            
            float totalDiffuse = keyDiff + rimDiff;
            vec3 diffuseColor = baseColor * totalDiffuse;
            
            // Blinn-Phong specular
            float shininess = 32.0;
            float specularStrength = 0.3;
            
            vec3 H1 = normalize(keyLight + V);
            float spec1 = pow(max(dot(N, H1), 0.0), shininess) * 2.0;
            
            vec3 H2 = normalize(rimLight + V);
            float spec2 = pow(max(dot(N, H2), 0.0), shininess) * 1.5;
            
            vec3 specularColor = vec3(1.0) * (spec1 + spec2) * specularStrength;

            vec3 finalColor = diffuseColor + specularColor;

            gl_FragColor = vec4(finalColor, 1.0);
        }
    `,
    transparent: false,
    side: THREE.DoubleSide,
    depthTest: true,
    depthWrite: true,
    polygonOffset: true,
    polygonOffsetFactor: 1,
    polygonOffsetUnits: 1
});

// ===== Shape Geometries =====
const shapeGeometries = {
    cube: () => new THREE.BoxGeometry(2, 2, 2),
    cylinder: () => new THREE.CylinderGeometry(1, 1, 2, 16),
    cone: () => new THREE.ConeGeometry(1, 2, 16),
    sphere: () => new THREE.SphereGeometry(1, 16, 16)
};

// Built-in/custom OBJ models served with the app (populated from models.json)
const presetModels = {};
const customModelListPath = 'models/models.json';

// ===== Lighting Configuration =====
let lightingRotation = 180;
let skyboxRotation = 212;
let vertexSize = 0.05;
let animationMaxTime = 2;
let floorHelpersVisible = true;
const lights = [rimLight];
const lightPositions = [
    { x: -4, y: 5, z: -3 }
];

function rotateLights(angle) {
    const rad = (angle * Math.PI) / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);

    lights.forEach((light, index) => {
        const pos = lightPositions[index];
        const x = pos.x * cos - pos.z * sin;
        const z = pos.x * sin + pos.z * cos;
        light.position.set(x, pos.y, z);
    });

    // Update shader uniforms if assembled mesh exists
    if (mesh && mesh.material && mesh.material.uniforms) {
        mesh.material.uniforms.rimLightPos.value.copy(rimLight.position);
    }

    // Update shader uniforms if faces mesh exists
    if (facesMesh && facesMesh.material && facesMesh.material.uniforms) {
        facesMesh.material.uniforms.rimLightPos.value.copy(rimLight.position);
    }

    // Update shader uniforms if inside faces mesh exists
    if (facesInnerMesh && facesInnerMesh.material && facesInnerMesh.material.uniforms) {
        facesInnerMesh.material.uniforms.rimLightPos.value.copy(rimLight.position);
    }
}

function rotateSkybox(angle) {
    // Update sun azimuth based on slider angle
    sunAzimuth = angle;
    updateSunPosition();

    // Also rotate the skybox mesh itself
    sky.rotation.y = (angle * Math.PI) / 180;

    // Update shader uniforms if assembled mesh exists
    if (mesh && mesh.material && mesh.material.uniforms) {
        mesh.material.uniforms.keyLightPos.value.copy(keyLight.position);
    }

    // Update shader uniforms if faces mesh exists
    if (facesMesh && facesMesh.material && facesMesh.material.uniforms) {
        facesMesh.material.uniforms.keyLightPos.value.copy(keyLight.position);
    }

    // Update shader uniforms if inside faces mesh exists
    if (facesInnerMesh && facesInnerMesh.material && facesInnerMesh.material.uniforms) {
        facesInnerMesh.material.uniforms.keyLightPos.value.copy(keyLight.position);
    }
}

// Safe wrapper to avoid runtime errors if rotateSkybox is unavailable
function applySkyboxRotation(angle) {
    if (typeof rotateSkybox === 'function') {
        rotateSkybox(angle);
    }
}

function updateVertexGeometry() {
    if (vertices) {
        // Kill any running animations before updating geometry
        gsap.killTweensOf(vertexScales);

        // Update geometry with new size
        vertices.geometry.dispose();
        vertices.geometry = new THREE.SphereGeometry(vertexSize, 5, 3);
    }
}

// ===== Initialization =====
console.log('Initializing...');
console.log('vertex-size input element:', document.getElementById('vertex-size'));
updateGeometry();
rotateLights(lightingRotation);
loadCustomModelsFromFile();

// ===== Event Listeners =====
document.getElementById('shape-select').addEventListener('change', async (e) => {
    currentShape = e.target.value;

    // Reset any OBJ-specific material when switching to primitives
    if (!presetModels[currentShape] && currentShape !== 'obj') {
        currentGeometry = null;
        currentMaterial = null;
    }

    if (currentShape === 'obj') {
        document.getElementById('obj-file').click();
        return;
    }

    if (presetModels[currentShape]) {
        await loadPresetModel(currentShape);
        return;
    }

    updateGeometry();
    resetScene();
});

document.getElementById('obj-file').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        showLoading('Loading OBJ file...');
        const reader = new FileReader();
        reader.onload = (event) => {
            const objLoader = new OBJLoader();
            try {
                const object = objLoader.parse(event.target.result);
                if (object.children.length > 0) {
                    currentGeometry = object.children[0].geometry;
                    currentMaterial = object.children[0].material || null;
                    if (!currentGeometry) {
                        currentGeometry = object.children[0];
                    }
                    updateGeometry();
                    resetScene();
                }
            } catch (error) {
                console.error('Error loading OBJ:', error);
            } finally {
                hideLoading();
            }

            // Check if model actually loaded by verifying vertices exist
            if (!currentGeometry || currentGeometry.attributes.position.count === 0) {
                alert('Error loading OBJ file. Make sure it\'s a valid OBJ file.');
            }
        };
        reader.readAsText(file);
    }
});

async function loadPresetModel(key) {
    const preset = presetModels[key];
    if (!preset) return;

    if (!preset.baseGeometry) {
        showLoading('Loading model...');
        try {
            const response = await fetch(preset.path);
            if (!response.ok) {
                throw new Error(`Failed to fetch ${preset.path}: ${response.status}`);
            }

            const objText = await response.text();
            const objLoader = new OBJLoader();
            const object = objLoader.parse(objText);
            const meshChild = object.children.find(child => child.isMesh) || object.children[0];

            if (!meshChild || !meshChild.geometry) {
                throw new Error('No mesh geometry found in OBJ file.');
            }

            preset.baseGeometry = meshChild.geometry.clone();
            preset.baseMaterial = meshChild.material ? meshChild.material.clone() : null;
        } catch (error) {
            console.error('Error loading OBJ:', error);
        } finally {
            hideLoading();
        }
    }

    // Clone before modifying so cached geometry stays pristine
    currentGeometry = preset.baseGeometry ? preset.baseGeometry.clone() : null;
    currentMaterial = preset.baseMaterial ? preset.baseMaterial.clone() : null;

    updateGeometry();
    resetScene();

    // Check if model actually loaded by verifying vertices exist
    if (!currentGeometry || currentGeometry.attributes.position.count === 0) {
        alert('Could not load the OBJ model. Please try again.');
    }
}

async function loadCustomModelsFromFile() {
    try {
        const response = await fetch(customModelListPath);
        if (!response.ok) {
            console.warn(`Custom model list not found: ${customModelListPath} (${response.status})`);
            return;
        }
        const data = await response.json();
        if (!Array.isArray(data)) {
            console.warn('models.json must be an array of { id, title, path }');
            return;
        }

        const selectEl = document.getElementById('shape-select');

        data.forEach((item) => {
            if (!item || !item.id || !item.path) return;
            const id = String(item.id);
            const title = item.title ? String(item.title) : id;
            const path = String(item.path);

            // Skip duplicates
            if (presetModels[id]) return;

            presetModels[id] = {
                path,
                baseGeometry: null,
                baseMaterial: null
            };

            const option = document.createElement('option');
            option.value = id;
            option.textContent = title;
            selectEl.appendChild(option);
        });

        // Ensure "Load OBJ File" is always at the bottom
        const objOption = selectEl.querySelector('option[value="obj"]');
        if (objOption) {
            selectEl.appendChild(objOption); // Moves it to the end
        }
    } catch (error) {
        console.warn('Failed to load custom models list:', error);
    }
}

document.getElementById('show-vertices').addEventListener('click', showVertices);
document.getElementById('connect-edges').addEventListener('click', connectEdges);
document.getElementById('form-faces').addEventListener('click', formFaces);
document.getElementById('assemble-mesh').addEventListener('click', assembleMesh);
document.getElementById('reset').addEventListener('click', resetScene);

// ===== Settings Panel Listeners =====
document.getElementById('lighting-rotation').addEventListener('input', (e) => {
    lightingRotation = parseFloat(e.target.value);
    rotateLights(lightingRotation);
    document.getElementById('lighting-rotation-value').textContent = lightingRotation + '°';
});

document.getElementById('skybox-rotation').addEventListener('input', (e) => {
    skyboxRotation = parseFloat(e.target.value);
    applySkyboxRotation(skyboxRotation);
    document.getElementById('skybox-rotation-value').textContent = skyboxRotation + '°';
});

// Initial sync of controls to defaults
rotateLights(lightingRotation);
applySkyboxRotation(skyboxRotation);
document.getElementById('lighting-rotation').value = lightingRotation;
document.getElementById('lighting-rotation-value').textContent = lightingRotation + '°';
document.getElementById('skybox-rotation').value = skyboxRotation;
document.getElementById('skybox-rotation-value').textContent = skyboxRotation + '°';

// Reset settings to defaults
document.getElementById('settings-reset').addEventListener('click', () => {
    // Defaults
    lightingRotation = 180;
    skyboxRotation = 212;
    vertexSize = 0.05;
    animationMaxTime = 2;
    floorHelpersVisible = true;

    // Sliders + labels
    const lightSlider = document.getElementById('lighting-rotation');
    lightSlider.value = lightingRotation;
    document.getElementById('lighting-rotation-value').textContent = lightingRotation + '°';
    rotateLights(lightingRotation);

    const skySlider = document.getElementById('skybox-rotation');
    skySlider.value = skyboxRotation;
    document.getElementById('skybox-rotation-value').textContent = skyboxRotation + '°';
    applySkyboxRotation(skyboxRotation);

    const vertexSlider = document.getElementById('vertex-size');
    vertexSlider.value = vertexSize;
    document.getElementById('vertex-size-value').textContent = vertexSize.toFixed(2);
    if (vertices) updateVertexGeometry();

    const animSlider = document.getElementById('animation-max-time');
    animSlider.value = animationMaxTime;
    document.getElementById('animation-max-time-value').textContent = animationMaxTime + 's';

    // Background color
    const bgInput = document.getElementById('bg-color');
    bgInput.value = '#333333';
    renderer.setClearColor(0x333333);
    document.body.style.background = '#333333';
    sky.material.uniforms.horizonColor.value.setHex(0x333333);

    // Toggles
    gridHelper.visible = true;
    floorAxesHelper.visible = true;
    // document.getElementById('toggle-floor-helpers').classList.add('active'); // Handled by init block below

    sky.visible = true;
    // document.getElementById('toggle-background').classList.add('active'); // Handled by init block below

    sky.material.uniforms.showHorizonCutoff.value = 0.0;
    // document.getElementById('toggle-skybox-bottom').classList.remove('active'); // Handled by init block below
});

let vertexSizeTimeout;
const vertexSizeInput = document.getElementById('vertex-size');
console.log('Setting up vertex-size listener:', vertexSizeInput);

// Test if mouse events are being detected
vertexSizeInput.addEventListener('mousedown', (e) => {
    console.log('vertex-size MOUSEDOWN event fired');
});

vertexSizeInput.addEventListener('touchstart', (e) => {
    console.log('vertex-size TOUCHSTART event fired');
});

vertexSizeInput.addEventListener('input', (e) => {
    console.log('vertex-size INPUT event fired:', e.target.value);
    vertexSize = parseFloat(e.target.value);
    document.getElementById('vertex-size-value').textContent = vertexSize.toFixed(2);

    // Debounce the geometry update to avoid lag while dragging
    clearTimeout(vertexSizeTimeout);
    vertexSizeTimeout = setTimeout(() => {
        console.log('vertex-size geometry update, vertices exist:', !!vertices);
        if (vertices) updateVertexGeometry();
    }, 150);
});
console.log('vertex-size listener attached');

document.getElementById('animation-max-time').addEventListener('input', (e) => {
    animationMaxTime = parseFloat(e.target.value);
    document.getElementById('animation-max-time-value').textContent = animationMaxTime.toFixed(1) + 's';
});

document.getElementById('toggle-floor-helpers').addEventListener('click', () => {
    floorHelpersVisible = !floorHelpersVisible;
    gridHelper.visible = floorHelpersVisible;
    floorAxesHelper.visible = floorHelpersVisible;
    document.getElementById('toggle-floor-helpers').classList.toggle('active', floorHelpersVisible);
});

document.getElementById('toggle-background').addEventListener('click', () => {
    sky.visible = !sky.visible;
    document.getElementById('toggle-background').classList.toggle('active', sky.visible);
});

document.getElementById('toggle-skybox-bottom').addEventListener('click', () => {
    const currentValue = sky.material.uniforms.showHorizonCutoff.value;
    sky.material.uniforms.showHorizonCutoff.value = currentValue > 0.5 ? 0.0 : 1.0;
    document.getElementById('toggle-skybox-bottom').classList.toggle('active', sky.material.uniforms.showHorizonCutoff.value > 0.5);
});

// Initialize toggle styles
document.getElementById('toggle-floor-helpers').classList.toggle('active', floorHelpersVisible);
document.getElementById('toggle-background').classList.toggle('active', sky.visible);
document.getElementById('toggle-skybox-bottom').classList.toggle('active', sky.material.uniforms.showHorizonCutoff.value > 0.5);

// ===== Color Picker =====
const bgColorInput = document.getElementById('bg-color');
bgColorInput.addEventListener('input', (e) => {
    const hexColor = e.target.value;
    const decimalColor = parseInt(hexColor.substring(1), 16);
    renderer.setClearColor(decimalColor);
    document.body.style.background = hexColor;
    // Also update skybox bottom color
    sky.material.uniforms.horizonColor.value.setHex(decimalColor);
});

// ===== Core Functions =====

function autoScaleAndPositionModel(geometry) {
    /**
     * Automatically scales and positions a model based on its bounding box:
     * 1. If longest dimension > 10 units: scale down to 10 units
     * 2. If longest dimension < 5 units: scale up to 5 units
     * 3. Apply vertical offset to place bottom of bounding box on floor (Y=-1)
     * Returns object with center and required camera distance to view entire model
     */
    if (!geometry) return { center: new THREE.Vector3(0, 0, 0), distance: 3 };

    // Calculate bounding box
    geometry.computeBoundingBox();
    const bbox = geometry.boundingBox;
    const bboxSize = bbox.getSize(new THREE.Vector3());
    const bboxMin = bbox.min;

    console.log('Initial bounding box:', { min: bboxMin.clone(), size: bboxSize.clone() });

    // Find longest dimension
    const maxDimension = Math.max(bboxSize.x, bboxSize.y, bboxSize.z);

    // Determine scale factor
    let scaleFactor = 1.0;
    if (maxDimension > 10) {
        scaleFactor = 10 / maxDimension;
    } else if (maxDimension < 5) {
        scaleFactor = 5 / maxDimension;
    }

    console.log('Scale factor:', scaleFactor, 'Max dimension:', maxDimension);

    // Apply scaling to all vertices
    if (scaleFactor !== 1.0) {
        const posAttr = geometry.attributes.position;
        for (let i = 0; i < posAttr.count; i++) {
            const vertex = new THREE.Vector3().fromBufferAttribute(posAttr, i);
            vertex.multiplyScalar(scaleFactor);
            posAttr.setXYZ(i, vertex.x, vertex.y, vertex.z);
        }
        posAttr.needsUpdate = true;
    }

    // Recalculate bounding box after scaling
    geometry.computeBoundingBox();
    const scaledBbox = geometry.boundingBox;
    const scaledBboxMin = scaledBbox.min;
    const scaledBboxSize = scaledBbox.getSize(new THREE.Vector3());

    console.log('After scaling, new min Y:', scaledBboxMin.y);

    // Calculate vertical offset to place bottom on floor (floor is at Y = -1)
    const floorY = -1;
    const verticalOffset = floorY - scaledBboxMin.y;

    console.log('Vertical offset to apply:', verticalOffset);

    // Apply vertical offset to all vertices
    if (Math.abs(verticalOffset) > 0.0001) {
        const posAttr = geometry.attributes.position;
        for (let i = 0; i < posAttr.count; i++) {
            const vertex = new THREE.Vector3().fromBufferAttribute(posAttr, i);
            vertex.y += verticalOffset;
            posAttr.setXYZ(i, vertex.x, vertex.y, vertex.z);
        }
        posAttr.needsUpdate = true;
    }

    // Verify final position and calculate center
    geometry.computeBoundingBox();
    const finalBbox = geometry.boundingBox;
    const bboxCenter = finalBbox.getCenter(new THREE.Vector3());
    const finalBboxSize = finalBbox.getSize(new THREE.Vector3());
    console.log('Final bounding box min Y:', finalBbox.min.y, '(should be -1 for floor)');
    console.log('Bounding box center:', bboxCenter.clone());

    // Calculate required camera distance to view entire model
    // Use the largest dimension of the bounding box
    const maxFinalDimension = Math.max(finalBboxSize.x, finalBboxSize.y, finalBboxSize.z);
    const cameraVFOV = 75; // vertical field of view in degrees
    const aspectRatio = window.innerWidth / window.innerHeight;

    // Determine which FOV to use based on window aspect ratio
    let effectiveFOV;
    if (aspectRatio > 1) {
        // Landscape (wider than tall) - use vertical FOV
        effectiveFOV = cameraVFOV;
    } else if (aspectRatio < 1) {
        // Portrait (taller than wide) - convert to horizontal FOV
        const vFOVRad = THREE.MathUtils.degToRad(cameraVFOV);
        const hFOVRad = 2 * Math.atan(Math.tan(vFOVRad / 2) * aspectRatio);
        effectiveFOV = THREE.MathUtils.radToDeg(hFOVRad);
    } else {
        // Square - use horizontal FOV
        const vFOVRad = THREE.MathUtils.degToRad(cameraVFOV);
        const hFOVRad = 2 * Math.atan(Math.tan(vFOVRad / 2) * aspectRatio);
        effectiveFOV = THREE.MathUtils.radToDeg(hFOVRad);
    }

    const fovRad = THREE.MathUtils.degToRad(effectiveFOV);
    // Calculate distance: distance = (maxDimension / 2) / tan(fov/2)
    const requiredDistance = (maxFinalDimension / 2) / Math.tan(fovRad / 2);
    // Add buffer (increased to 2.0 to handle diagonals of blocky shapes like cubes)
    const cameraDistance = requiredDistance * 2.0;

    console.log('Aspect ratio:', aspectRatio, 'Effective FOV:', effectiveFOV, 'Max final dimension:', maxFinalDimension, 'Required distance:', requiredDistance, 'Final distance:', cameraDistance);

    return { center: bboxCenter, distance: cameraDistance };
}

function updateGeometry() {
    if (!currentGeometry) {
        const shapeFactory = shapeGeometries[currentShape];
        if (shapeFactory) {
            currentGeometry = shapeFactory();
            currentMaterial = null;
        } else if (currentShape === 'obj') {
            return;
        } else {
            console.warn('No geometry factory found for shape:', currentShape);
            return;
        }
    }
    const result = autoScaleAndPositionModel(currentGeometry);
    const { center, distance } = result;

    // Use centralized camera update
    updateCameraView(center, distance);

    extractData();
    updateInfo();
}

function updateCameraView(center, distance) {
    // Update camera target to center on the model
    controls.target.copy(center);

    // Position camera back from the center to view entire model
    const cameraDirection = new THREE.Vector3(0.5, 0.6, 0.7).normalize();
    camera.position.copy(center).addScaledVector(cameraDirection, distance);

    controls.update();
}

function extractData() {
    if (!currentGeometry) return;

    // Extract vertices
    const posAttr = currentGeometry.attributes.position;
    verticesData = [];
    for (let i = 0; i < posAttr.count; i++) {
        verticesData.push(new THREE.Vector3().fromBufferAttribute(posAttr, i));
    }

    // Extract faces (triangles)
    facesData = [];
    if (currentGeometry.index) {
        for (let i = 0; i < currentGeometry.index.count; i += 3) {
            facesData.push([
                currentGeometry.index.array[i],
                currentGeometry.index.array[i + 1],
                currentGeometry.index.array[i + 2]
            ]);
        }
    } else {
        for (let i = 0; i < posAttr.count; i += 3) {
            facesData.push([i, i + 1, i + 2]);
        }
    }

    // Extract edges from faces
    const edgeSet = new Set();
    facesData.forEach(face => {
        const [a, b, c] = face;
        const edgeList = [
            [Math.min(a, b), Math.max(a, b)],
            [Math.min(b, c), Math.max(b, c)],
            [Math.min(c, a), Math.max(c, a)]
        ];
        edgeList.forEach(e => edgeSet.add(`${e[0]}-${e[1]}`));
    });
    edgesData = Array.from(edgeSet).map(s => s.split('-').map(Number));
}

function showVertices() {
    if (!vertices) {
        // Create InstancedMesh for all vertices (one draw call)
        const geometry = new THREE.SphereGeometry(vertexSize, 5, 3);
        const material = new THREE.MeshStandardMaterial({
            color: 0xff0000,
            emissive: new THREE.Color(0xff0000),
            emissiveIntensity: 0.5,
            metalness: 0.3,
            roughness: 0.6,
            envMapIntensity: 0.8
        });
        vertices = new THREE.InstancedMesh(geometry, material, verticesData.length);
        // Expose for debugging/inspection
        window.verticesMesh = vertices;
        vertices.castShadow = true;
        vertices.receiveShadow = true;
        vertices.visible = false;
        scene.add(vertices);

        // Initialize vertex scales and matrices
        vertexScales = verticesData.map(() => 0);
        const matrix = new THREE.Matrix4();
        verticesData.forEach((pos, index) => {
            matrix.compose(
                pos,
                new THREE.Quaternion(),
                new THREE.Vector3(0, 0, 0)
            );
            vertices.setMatrixAt(index, matrix);
        });
    }

    // Kill any running animations
    gsap.killTweensOf(vertexScales);

    // Calculate proportional delays
    const BASE_DURATION = 0.5;
    const MAX_TIME = animationMaxTime;
    const itemCount = verticesData.length;
    const effectiveDuration = Math.min(BASE_DURATION, MAX_TIME);
    const delayPerItem = itemCount > 1 ? Math.max(0, (MAX_TIME - effectiveDuration) / (itemCount - 1)) : 0;

    // Instant feedback
    const btn = document.getElementById('show-vertices');
    if (btn) btn.classList.toggle('active', !vertices.visible);

    if (!vertices.visible) {
        // Show with animation
        verticesData.forEach((pos, index) => {
            vertexScales[index] = 0;
            const matrix = new THREE.Matrix4();
            matrix.compose(pos, new THREE.Quaternion(), new THREE.Vector3(0, 0, 0));
            vertices.setMatrixAt(index, matrix);
        });
        vertices.instanceMatrix.needsUpdate = true;
        vertices.visible = true;

        if (MAX_TIME === 0) {
            verticesData.forEach((pos, index) => {
                const matrix = new THREE.Matrix4();
                matrix.compose(pos, new THREE.Quaternion(), new THREE.Vector3(1, 1, 1));
                vertices.setMatrixAt(index, matrix);
            });
            vertices.instanceMatrix.needsUpdate = true;
        } else {
            // Performance Fix: Single tween driving all instances instead of N tweens
            const animData = { progress: 0 };

            // Kill previous animation
            if (activeVerticesTween) activeVerticesTween.kill();

            activeVerticesTween = gsap.to(animData, {
                progress: 1,
                duration: effectiveDuration + (verticesData.length * delayPerItem), // Total time covers all staggers
                ease: "none",
                onUpdate: () => {
                    if (!vertices) return;

                    const currentTime = animData.progress * (effectiveDuration + (verticesData.length * delayPerItem));
                    let needsUpdate = false;

                    for (let i = 0; i < verticesData.length; i++) {
                        // Calculate local progress for this item based on its start time
                        const startTime = i * delayPerItem;
                        // Map global time to local 0-1 factor
                        let factor = (currentTime - startTime) / effectiveDuration;
                        factor = Math.max(0, Math.min(1, factor)); // Clamp 0-1

                        // Optimization: Only update if changing or not yet final
                        // (Use tracking array to avoid redundant updates if desired, but this math is cheap)

                        const scale = factor;
                        const matrix = new THREE.Matrix4();
                        matrix.compose(
                            verticesData[i],
                            new THREE.Quaternion(),
                            new THREE.Vector3(scale, scale, scale)
                        );
                        vertices.setMatrixAt(i, matrix);
                        needsUpdate = true;
                    }

                    if (needsUpdate) {
                        vertices.instanceMatrix.needsUpdate = true;
                    }
                },
                onComplete: () => {
                    activeVerticesTween = null;
                }
            });
        }
    } else {
        // Hide with reverse animation
        if (MAX_TIME === 0) {
            vertices.visible = false;
        } else {
            const animData = { progress: 0 };
            const totalDuration = effectiveDuration + (verticesData.length * delayPerItem);

            // Kill previous animation
            if (activeVerticesTween) activeVerticesTween.kill();

            activeVerticesTween = gsap.to(animData, {
                progress: 1,
                duration: totalDuration,
                ease: "none",
                onUpdate: () => {
                    if (!vertices) return;

                    const currentTime = animData.progress * totalDuration;
                    let needsUpdate = false;

                    for (let i = 0; i < verticesData.length; i++) {
                        // Reverse index logic: last item starts first
                        const reverseIndex = (verticesData.length - 1) - i;
                        const startTime = i * delayPerItem; // Linear delay based on loop index

                        // Map to local 0-1 factor (reversed: 1 -> 0)
                        let factor = (currentTime - startTime) / effectiveDuration;
                        factor = 1 - Math.max(0, Math.min(1, factor)); // Invert for hiding

                        const scale = factor;
                        const matrix = new THREE.Matrix4();
                        matrix.compose(
                            verticesData[reverseIndex], // Use reverseIndex for position to match visual 'unzipping'
                            new THREE.Quaternion(),
                            new THREE.Vector3(scale, scale, scale)
                        );
                        vertices.setMatrixAt(reverseIndex, matrix);
                        needsUpdate = true;
                    }

                    if (needsUpdate) {
                        vertices.instanceMatrix.needsUpdate = true;
                    }
                },
                onComplete: () => {
                    if (vertices) vertices.visible = false;
                    activeVerticesTween = null;
                }
            });
        }
    }
}

function connectEdges() {
    // Ensure geometry/data is available independent of vertices mesh
    if (!currentGeometry) {
        updateGeometry();
        if (!currentGeometry) return;
    }
    if (!verticesData || verticesData.length === 0 || !edgesData || edgesData.length === 0) {
        extractData();
    }

    if (!edgesMesh) {
        // Merge all edges into single geometry
        const positions = [];
        const visibilityArray = [];

        edgesData.forEach((edge, edgeIndex) => {
            const p1 = verticesData[edge[0]];
            const p2 = verticesData[edge[1]];

            // Add two vertices per line
            positions.push(p1.x, p1.y, p1.z);
            positions.push(p2.x, p2.y, p2.z);

            // Both vertices of the line share same visibility for this edge
            visibilityArray.push(0, 0);
        });

        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(positions), 3));
        geometry.setAttribute('visibility', new THREE.BufferAttribute(new Float32Array(visibilityArray), 1));

        // Clone the material for this instance
        const material = edgeShaderMaterial.clone();
        edgesMesh = new THREE.LineSegments(geometry, material);
        edgesMesh.visible = false;
        scene.add(edgesMesh);

        // Initialize visibility tracking
        edgeVisibility = edgesData.map(() => 0);
    }

    // Kill any running animations
    gsap.killTweensOf(edgeVisibility);

    // Calculate proportional delays
    const BASE_DURATION = 0.3;
    const MAX_TIME = animationMaxTime;
    const itemCount = edgesData.length;
    const effectiveDuration = Math.min(BASE_DURATION, MAX_TIME);
    const delayPerItem = itemCount > 1 ? Math.max(0, (MAX_TIME - effectiveDuration) / (itemCount - 1)) : 0;
    const geometry = edgesMesh.geometry;

    // Instant feedback
    const btn = document.getElementById('connect-edges');
    if (btn) btn.classList.toggle('active', !edgesMesh.visible);

    if (!edgesMesh.visible) {
        // Show with animation
        edgesData.forEach((edge, edgeIndex) => {
            edgeVisibility[edgeIndex] = 0;
            const visAttr = geometry.attributes.visibility.array;
            visAttr[edgeIndex * 2] = 0;
            visAttr[edgeIndex * 2 + 1] = 0;
        });
        geometry.attributes.visibility.needsUpdate = true;
        edgesMesh.visible = true;

        if (MAX_TIME === 0) {
            edgesData.forEach((edge, edgeIndex) => {
                edgeVisibility[edgeIndex] = 1;
                const visAttr = geometry.attributes.visibility.array;
                visAttr[edgeIndex * 2] = 1;
                visAttr[edgeIndex * 2 + 1] = 1;
            });
            geometry.attributes.visibility.needsUpdate = true;
        } else {
            // Performance Fix: Single tween driving all instances
            const animData = { progress: 0 };
            const totalDuration = effectiveDuration + (edgesData.length * delayPerItem);

            // Kill previous animation
            if (activeEdgesTween) activeEdgesTween.kill();

            activeEdgesTween = gsap.to(animData, {
                progress: 1,
                duration: totalDuration,
                ease: "none",
                onUpdate: () => {
                    const currentTime = animData.progress * totalDuration;
                    const visAttr = geometry.attributes.visibility.array;
                    let needsUpdate = false;

                    for (let i = 0; i < edgesData.length; i++) {
                        const startTime = i * delayPerItem;
                        let val = (currentTime - startTime) / effectiveDuration;
                        val = Math.max(0, Math.min(1, val));

                        edgeVisibility[i] = val;
                        visAttr[i * 2] = val;
                        visAttr[i * 2 + 1] = val;
                        needsUpdate = true;
                    }
                    if (needsUpdate) {
                        geometry.attributes.visibility.needsUpdate = true;
                    }
                },
                onComplete: () => {
                    activeEdgesTween = null;
                }
            });
        }
    } else {
        // Hide with reverse animation
        if (MAX_TIME === 0) {
            edgesMesh.visible = false;
        } else {
            // Performance Fix: Single tween driving all instances (Reverse)
            const animData = { progress: 0 };
            const totalDuration = effectiveDuration + (edgesData.length * delayPerItem);

            // Kill previous animation
            if (activeEdgesTween) activeEdgesTween.kill();

            activeEdgesTween = gsap.to(animData, {
                progress: 1,
                duration: totalDuration,
                ease: "none",
                onUpdate: () => {
                    if (!edgesMesh) return;
                    const currentTime = animData.progress * totalDuration;
                    const visAttr = geometry.attributes.visibility.array;
                    let needsUpdate = false;

                    for (let i = 0; i < edgesData.length; i++) {
                        // Reverse index logic
                        const reverseIndex = (edgesData.length - 1) - i;
                        const startTime = i * delayPerItem;

                        let val = (currentTime - startTime) / effectiveDuration;
                        val = 1 - Math.max(0, Math.min(1, val)); // Invert

                        edgeVisibility[reverseIndex] = val;
                        visAttr[reverseIndex * 2] = val;
                        visAttr[reverseIndex * 2 + 1] = val;
                        needsUpdate = true;
                    }
                    if (needsUpdate) {
                        geometry.attributes.visibility.needsUpdate = true;
                    }
                },
                onComplete: () => {
                    if (edgesMesh) edgesMesh.visible = false;
                    activeEdgesTween = null;
                }
            });
        }
    }
}

function formFaces() {
    // Ensure geometry/data is available independent of vertices mesh
    if (!currentGeometry) {
        updateGeometry();
        if (!currentGeometry) return;
    }
    if (!verticesData || verticesData.length === 0 || !facesData || facesData.length === 0) {
        extractData();
    }

    if (!facesMesh) {
        // Merge all faces into single geometry
        const positions = [];
        const visibilityArray = [];

        facesData.forEach((face, faceIndex) => {
            const v0 = verticesData[face[0]];
            const v1 = verticesData[face[1]];
            const v2 = verticesData[face[2]];

            // Add three vertices per triangle
            positions.push(v0.x, v0.y, v0.z);
            positions.push(v1.x, v1.y, v1.z);
            positions.push(v2.x, v2.y, v2.z);

            // All three vertices of the triangle share same visibility for this face
            visibilityArray.push(0, 0, 0);
        });

        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(positions), 3));
        geometry.setAttribute('visibility', new THREE.BufferAttribute(new Float32Array(visibilityArray), 1));
        geometry.computeVertexNormals();

        // Outside pass: front faces only, writes depth (occludes inside)
        const outsideMaterial = faceShaderMaterial.clone();
        outsideMaterial.side = THREE.FrontSide;
        outsideMaterial.uniforms.inside.value = 0.0;
        outsideMaterial.uniforms.keyLightPos.value.copy(keyLight.position);
        outsideMaterial.uniforms.rimLightPos.value.copy(rimLight.position);
        facesMesh = new THREE.Mesh(geometry, outsideMaterial);
        facesMesh.renderOrder = 1; // draw before assembled mesh
        facesMesh.visible = false;
        scene.add(facesMesh);

        // Inside pass: back faces only, draws after outside
        const insideMaterial = faceShaderMaterial.clone();
        insideMaterial.side = THREE.BackSide;
        insideMaterial.uniforms.inside.value = 1.0;
        // Push inside slightly back in depth to avoid silhouette leakage
        insideMaterial.polygonOffset = true;
        insideMaterial.polygonOffsetFactor = 2;
        insideMaterial.polygonOffsetUnits = 2;
        insideMaterial.uniforms.keyLightPos.value.copy(keyLight.position);
        insideMaterial.uniforms.rimLightPos.value.copy(rimLight.position);
        facesInnerMesh = new THREE.Mesh(geometry, insideMaterial);
        facesInnerMesh.renderOrder = 1.05;
        facesInnerMesh.visible = false;
        scene.add(facesInnerMesh);

        // Initialize visibility tracking
        faceVisibility = facesData.map(() => 0);
    }

    // Kill any running animations
    gsap.killTweensOf(faceVisibility);

    // Calculate proportional delays
    const BASE_DURATION = 0.4;
    const MAX_TIME = animationMaxTime;
    const itemCount = facesData.length;
    const effectiveDuration = Math.min(BASE_DURATION, MAX_TIME);
    const delayPerItem = itemCount > 1 ? Math.max(0, (MAX_TIME - effectiveDuration) / (itemCount - 1)) : 0;
    const geometry = facesMesh.geometry;

    // Instant feedback
    const btn = document.getElementById('form-faces');
    if (btn) btn.classList.toggle('active', !facesMesh.visible);

    if (!facesMesh.visible) {
        // Show with animation
        facesData.forEach((face, faceIndex) => {
            faceVisibility[faceIndex] = 0;
            const visAttr = geometry.attributes.visibility.array;
            visAttr[faceIndex * 3] = 0;
            visAttr[faceIndex * 3 + 1] = 0;
            visAttr[faceIndex * 3 + 2] = 0;
        });
        geometry.attributes.visibility.needsUpdate = true;
        facesMesh.visible = true;
        if (facesInnerMesh) facesInnerMesh.visible = true;

        if (MAX_TIME === 0) {
            facesData.forEach((face, faceIndex) => {
                faceVisibility[faceIndex] = 1;
                const visAttr = geometry.attributes.visibility.array;
                visAttr[faceIndex * 3] = 1;
                visAttr[faceIndex * 3 + 1] = 1;
                visAttr[faceIndex * 3 + 2] = 1;
            });
            geometry.attributes.visibility.needsUpdate = true;
        } else {
            // Performance Fix: Single tween driving all instances
            const animData = { progress: 0 };
            const totalDuration = effectiveDuration + (facesData.length * delayPerItem);

            // Kill previous animation
            if (activeFacesTween) activeFacesTween.kill();

            activeFacesTween = gsap.to(animData, {
                progress: 1,
                duration: totalDuration,
                ease: "none",
                onUpdate: () => {
                    const currentTime = animData.progress * totalDuration;
                    const visAttr = geometry.attributes.visibility.array;
                    let needsUpdate = false;

                    for (let i = 0; i < facesData.length; i++) {
                        const startTime = i * delayPerItem;
                        let val = (currentTime - startTime) / effectiveDuration;
                        val = Math.max(0, Math.min(1, val));

                        faceVisibility[i] = val;
                        visAttr[i * 3] = val;
                        visAttr[i * 3 + 1] = val;
                        visAttr[i * 3 + 2] = val;
                        needsUpdate = true;
                    }
                    if (needsUpdate) {
                        geometry.attributes.visibility.needsUpdate = true;
                    }
                },
                onComplete: () => {
                    activeFacesTween = null;
                }
            });
        }
    } else {
        // Hide with reverse animation
        if (MAX_TIME === 0) {
            facesMesh.visible = false;
            if (facesInnerMesh) facesInnerMesh.visible = false;
        } else {
            // Performance Fix: Single tween driving all instances (Reverse)
            const animData = { progress: 0 };
            const totalDuration = effectiveDuration + (facesData.length * delayPerItem);

            // Kill previous animation
            if (activeFacesTween) activeFacesTween.kill();

            activeFacesTween = gsap.to(animData, {
                progress: 1,
                duration: totalDuration,
                ease: "none",
                onUpdate: () => {
                    if (!facesMesh) return;
                    const currentTime = animData.progress * totalDuration;
                    const visAttr = geometry.attributes.visibility.array;
                    let needsUpdate = false;

                    for (let i = 0; i < facesData.length; i++) {
                        // Reverse index logic
                        const reverseIndex = (facesData.length - 1) - i;
                        const startTime = i * delayPerItem;

                        let val = (currentTime - startTime) / effectiveDuration;
                        val = 1 - Math.max(0, Math.min(1, val)); // Invert

                        faceVisibility[reverseIndex] = val;
                        visAttr[reverseIndex * 3] = val;
                        visAttr[reverseIndex * 3 + 1] = val;
                        visAttr[reverseIndex * 3 + 2] = val;
                        needsUpdate = true;
                    }
                    if (needsUpdate) {
                        geometry.attributes.visibility.needsUpdate = true;
                    }
                },
                onComplete: () => {
                    if (facesMesh) {
                        facesMesh.visible = false;
                        if (facesInnerMesh) facesInnerMesh.visible = false;
                    }
                    activeFacesTween = null;
                }
            });
        }
    }
}

function assembleMesh() {
    // Ensure we have geometry available independent of faces
    if (!currentGeometry) {
        updateGeometry();
        if (!currentGeometry) return;
    }

    if (!mesh) {
        // Don't hide faces yet - they'll stay visible during dissolve
        // facesMesh.visible = false;
        // document.getElementById('form-faces').textContent = 'Show Faces';

        // Create complete mesh with dither dissolve shader
        const geometry = currentGeometry.clone();

        // Get base color from original material or use default
        let baseColor = new THREE.Color(0xffffff);
        if (currentMaterial && currentMaterial.color) {
            baseColor.copy(currentMaterial.color);
        }

        // Custom shader material with dither dissolve effect and PBR
        const material = new THREE.ShaderMaterial({
            uniforms: {
                dissolve: { value: 0 },
                keyLightPos: { value: keyLight.position.clone() },
                rimLightPos: { value: rimLight.position.clone() }
            },
            vertexShader: `
                varying vec3 vNormal;
                varying vec3 vWorldPosition;
                
                void main() {
                    // Transform normal to world space
                    vNormal = normalize(mat3(modelMatrix) * normal);
                    vec4 worldPosition = modelMatrix * vec4(position, 1.0);
                    vWorldPosition = worldPosition.xyz;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform float dissolve;
                uniform vec3 keyLightPos;
                uniform vec3 rimLightPos;
                
                varying vec3 vNormal;
                varying vec3 vWorldPosition;
                
                // Simple hash function for dither pattern
                float hash(vec3 p) {
                    return fract(sin(dot(p, vec3(12.9898, 78.233, 45.164))) * 43758.5453);
                }
                
                void main() {
                    // Dither dissolve
                    float dither = hash(vWorldPosition * 10.0 + vec3(dissolve * 5.0));
                    if (dither > dissolve) discard;
                    
                    vec3 N = normalize(vNormal);
                    vec3 V = normalize(cameraPosition - vWorldPosition);
                    
                    // Normalized light directions
                    vec3 keyLight = normalize(keyLightPos - vWorldPosition);
                    vec3 rimLight = normalize(rimLightPos - vWorldPosition);
                    
                    // Lambert diffuse
                    float keyDiff = max(dot(N, keyLight), 0.0) * 2.0;
                    float rimDiff = max(dot(N, rimLight), 0.0) * 1.5;
                    
                    float totalDiffuse = keyDiff + rimDiff;
                    vec3 diffuseColor = vec3(0.5) * totalDiffuse;
                    
                    // Blinn-Phong specular
                    float shininess = 32.0;
                    float specularStrength = 0.3;
                    
                    vec3 H1 = normalize(keyLight + V);
                    float spec1 = pow(max(dot(N, H1), 0.0), shininess) * 2.0;
                    
                    vec3 H2 = normalize(rimLight + V);
                    float spec2 = pow(max(dot(N, H2), 0.0), shininess) * 1.5;
                    
                    vec3 specularColor = vec3(1.0) * (spec1 + spec2) * specularStrength;
                    
                    vec3 finalColor = diffuseColor + specularColor;
                    
                    gl_FragColor = vec4(finalColor, 1.0);
                }
            `,
            side: THREE.FrontSide,
            depthTest: true,
            depthWrite: true
        });

        mesh = new THREE.Mesh(geometry, material);
        mesh.renderOrder = 2; // ensure assembled renders after faces
        scene.add(mesh);

        // Instant feedback
        const btn = document.getElementById('assemble-mesh');
        if (btn) btn.classList.add('active');

        // Animate dither dissolve - duration equals slider value
        const ASSEMBLY_DURATION = Math.max(0, animationMaxTime);
        // Reset dissolve and kill any previous tweens
        gsap.killTweensOf(material.uniforms.dissolve);
        material.uniforms.dissolve.value = 0;
        if (ASSEMBLY_DURATION === 0) {
            material.uniforms.dissolve.value = 1;
        } else {
            gsap.to(material.uniforms.dissolve, {
                value: 1,
                duration: ASSEMBLY_DURATION,
                ease: "none"
            });
        }
    } else {
        // Always animate on toggle
        const material = mesh.material;
        const ASSEMBLY_DURATION = Math.max(0, animationMaxTime);
        gsap.killTweensOf(material.uniforms.dissolve);

        // Instant feedback
        const btn = document.getElementById('assemble-mesh');
        if (btn) btn.classList.toggle('active', !mesh.visible);

        if (!mesh.visible) {
            // Show with dissolve-in
            material.uniforms.dissolve.value = 0;
            mesh.visible = true;
            if (ASSEMBLY_DURATION === 0) {
                material.uniforms.dissolve.value = 1;
            } else {
                // Kill previous animation
                if (activeMeshTween) activeMeshTween.kill();

                activeMeshTween = gsap.to(material.uniforms.dissolve, {
                    value: 1,
                    duration: ASSEMBLY_DURATION,
                    ease: "none",
                    onComplete: () => {
                        activeMeshTween = null;
                    }
                });
            }
        } else {
            // Hide with dissolve animation
            if (mesh) {
                const material = mesh.material;

                if (ASSEMBLY_DURATION === 0) {
                    material.uniforms.dissolve.value = 0;
                    mesh.visible = false;
                } else {
                    // Kill previous animation
                    if (activeMeshTween) activeMeshTween.kill();

                    activeMeshTween = gsap.to(material.uniforms.dissolve, {
                        value: 0,
                        duration: ASSEMBLY_DURATION,
                        ease: "none",
                        onComplete: () => {
                            mesh.visible = false;
                            activeMeshTween = null;
                        }
                    });
                }
            }
        }
    }

}

function resetScene() {
    clearObjects();
    document.getElementById('info-text').textContent = 'Click buttons to visualize 3D modeling concepts';
    updateInfo();

    // Reset button states
    ['show-vertices', 'connect-edges', 'form-faces', 'assemble-mesh'].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.classList.remove('active');
    });
}

function clearObjects() {
    // Kill all running GSAP animations to prevent null reference errors
    gsap.killTweensOf(vertexScales);
    gsap.killTweensOf(edgeVisibility);
    gsap.killTweensOf(faceVisibility);

    if (vertices) {
        scene.remove(vertices);
        vertices = null;
        window.verticesMesh = null;
        vertexScales = [];
    }
    if (edgesMesh) {
        scene.remove(edgesMesh);
        edgesMesh = null;
        edgeVisibility = [];
    }
    if (facesMesh) {
        scene.remove(facesMesh);
        facesMesh = null;
        faceVisibility = [];
    }
    if (facesInnerMesh) {
        scene.remove(facesInnerMesh);
        facesInnerMesh = null;
    }
    if (mesh) scene.remove(mesh);
    mesh = null;
}

function updateInfo() {
    document.getElementById('vertex-count').textContent = verticesData.length;
    document.getElementById('edge-count').textContent = edgesData.length;
    document.getElementById('face-count').textContent = facesData.length;
}

// ===== Mobile & Desktop UI Management =====
// Global state for access in animate loop
let isCollapsed = false;
const isMobile = () => window.innerWidth <= 535;
let currentMode = isMobile() ? 'mobile' : 'desktop';

// ===== Animation Loop =====
function animate() {
    requestAnimationFrame(animate);
    controls.update();

    // Apply camera offset for panels (after OrbitControls update)
    // Only applies when settings panel is expanded (interactive state)
    // And if the user has enabled the offset behavior
    const offsetToggle = document.getElementById('camera-offset-toggle');
    const offsetEnabled = offsetToggle ? offsetToggle.checked : true;

    if (!isCollapsed && offsetEnabled) {
        if (currentMode === 'mobile') {
            // Mobile: Rotate around right axis (local X)
            // Use -20 degrees as per requirement
            camera.rotateX(THREE.MathUtils.degToRad(-20));
        } else {
            // Desktop: Rotate around local Up axis (Yaw)
            const angle = THREE.MathUtils.degToRad(-12);
            const up = camera.up.clone().normalize();
            const quat = new THREE.Quaternion().setFromAxisAngle(up, angle);
            camera.quaternion.premultiply(quat);
        }
    }

    // Update navigation axes orientation
    const camQuat = camera.quaternion.clone();
    camQuat.invert();
    axesHelper.quaternion.copy(camQuat);

    // Sky follows camera position
    sky.position.copy(camera.position);

    renderer.render(scene, camera);
}
animate();

// ===== Window Resize Handler =====
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
});

// ===== Service Worker Registration =====
if ('serviceWorker' in navigator) {
    const baseUrl = new URL('.', import.meta.url).pathname;
    navigator.serviceWorker.register('service-worker.js', { scope: baseUrl })
        .then(reg => console.log('Service Worker registered with scope:', reg.scope))
        .catch(err => console.log('Service Worker registration failed:', err));
}

// ===== UI Initialization & Event Handling =====
(function initUI() {
    const settingsPanel = document.getElementById('settings');

    // Helper to apply offsets immediately on interaction (optional, but good for responsiveness)
    function applyPanelCameraOffset() {
        // We leave the continuous update to animate(), but we can ensure controls are fresh
        controls.update();
    }

    function syncPanelState() {
        // Apply the user's preference (collapsed or not) based on current layout
        if (isCollapsed) {
            settingsPanel.classList.add('collapsed');
            settingsPanel.classList.remove('expanded');
        } else {
            settingsPanel.classList.remove('collapsed');
            settingsPanel.classList.add('expanded');
        }
    }

    function applyMobileStyles() {
        if (isMobile()) {
            settingsPanel.style.position = 'fixed';
        } else {
            // In desktop mode, let CSS handle positioning (don't override with inline styles)
            settingsPanel.style.position = '';
        }
        // Sync the panel state after layout change
        syncPanelState();
    }

    if (settingsPanel) {
        // Start with panel closed on mobile, open on desktop
        // Initialize state
        isCollapsed = isMobile(); // Default closed on mobile, open on desktop
        applyMobileStyles();

        // Updated: Click handler for the *entire* header
        const header = settingsPanel.querySelector('.settings-header');
        if (header) {
            header.addEventListener('click', (e) => {
                // Toggle state
                isCollapsed = !isCollapsed;
                syncPanelState();
            });
        }
    }

    // Reapply mobile styles on resize, but only sync state if mode changed
    window.addEventListener('resize', () => {
        if (settingsPanel) {
            const newMode = isMobile() ? 'mobile' : 'desktop';
            if (newMode !== currentMode) {
                currentMode = newMode;
                // Mode changed (mobile <-> desktop), apply layout change
                // Temporarily disable transitions to prevent animation on breakpoint change
                settingsPanel.style.transition = 'none';

                const controlGroups = settingsPanel.querySelectorAll('.control-group');
                controlGroups.forEach(el => el.style.transition = 'none');

                currentMode = newMode;
                applyMobileStyles();

                // Re-enable transitions after a frame
                requestAnimationFrame(() => {
                    requestAnimationFrame(() => {
                        settingsPanel.style.transition = '';
                        controlGroups.forEach(el => el.style.transition = '');
                    });
                });
            } else {
                // Same mode, just update position without triggering animation
                if (currentMode === 'mobile') {
                    settingsPanel.style.position = 'fixed';
                } else {
                    settingsPanel.style.position = '';
                }
            }
        }
    });

    // Recenter button functionality
    const recenterBtn = document.getElementById('recenter-container');
    if (recenterBtn) {
        recenterBtn.addEventListener('click', () => {
            if (!currentGeometry) return;

            // Recalculate view based on current model's bounding box
            const { center, distance } = autoScaleAndPositionModel(currentGeometry);

            // Use the centralized camera update function
            updateCameraView(center, distance);
        });
    }

    console.log('UI initialized with state persistence');
})();
